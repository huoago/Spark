# Spark Token → Web/WXSS 生成器 · v1.0

将设计令牌（JSON）一键生成：
- **Web**：`:root` CSS Variables（`dist/web/tokens.css`）与可直接落地的 `spark.css`
- **微信小程序**：不可用 CSS 变量，改为自动生成 **实用类（utilities）**（`dist/wx/app-tokens.wxss`）
- **Meta**：输出 `tokens.flat.json` 便于调试或接入其他工具

## 快速开始
```bash
npm i
npm run gen
# 输出目录：dist/
```

或者自定义参数：
```bash
node src/generate.mjs \  --in tokens/tokens.json \  --out dist \  --prefix sp \  --base-width 375   # 设计基准宽度（px），用于 px→rpx 转换（rpx = px/375*750）
```

## 令牌命名与映射规则
- JSON 示例见 `tokens/tokens.json`，支持层级结构：`color.*`、`radius.*`、`size.*`、`effect.*`
- **Web 映射**：
  - `color.bg` → `--sp-bg`，`color.textMuted` → `--sp-text-muted`
  - `size.*` / `radius.*` 数值自动加 `px`
  - 产出文件：`dist/web/tokens.css`（仅变量）与 `dist/web/spark.css`（变量 + 基础工具类模板）
- **WXSS 映射**（无 CSS 变量）：
  - `color.*` → `.bg-xxx { background: ... }` 与 `.text-xxx { color: ... }`
  - `radius.*` → `.radius-xxx { border-radius: ...rpx }`（按 `--base-width` 转换）
  - `size.fab` → `.fab { width/height: ...rpx }`、`size.icon` → `.icon { ... }`、`size.gap` → `.gap { gap: ...rpx }`
  - `effect.shadow/glow` → `.shadow/.glow { box-shadow: ... }`
  - 产出文件：`dist/wx/app-tokens.wxss`（已合并模板 `templates/wx/base.wxss`）

## 常见用法
- **Web**：
  ```html
  <link rel="stylesheet" href="/dist/web/spark.css" />
  <!-- 使用变量 -->
  <button class="sp-fab">…</button>
  ```
- **微信小程序**：
  ```xml
  <!-- app.wxss 或页面 wxss -->
  @import "/dist/wx/app-tokens.wxss";
  <!-- 使用 utilities -->
  <view class="bar shadow">…</view>
  <view class="fab glow">…</view>
  <text class="text-text-muted">副文本</text>
  ```

## 注意事项
- WXSS 不支持 CSS variables，因此采用可落地的 utility 类方式。
- 如果你需要多主题（暗/亮），可以维护多份 tokens.json（如 `tokens.dark.json` / `tokens.light.json`），分别生成 `app-tokens-dark.wxss` 与 `app-tokens-light.wxss`，在运行时切换 `@import`。
- `--base-width` 默认为 **375px**（典型 iPhone 逻辑宽），转换公式：`rpx = px / base * 750`。

## 许可证
MIT © 2025 Spark
