# Spark 多端样式体系（H5 + 小程序 + 桌面）

> 一套支持 **Design Tokens → Web/WXSS 自动生成**、**Style Dictionary 导入**、**多主题（gen:themes）** 的前端样式资产。适配 Spark 视频聊天等核心界面。  
> MIT © 2025 Spark

<div align="center">
  <img src="docs/theme-dark.png" width="46%" alt="Dark Theme Preview" />
  <img src="docs/theme-light.png" width="46%" alt="Light Theme Preview" />
</div>

## 目录结构（关键）
```
web/                # H5/桌面可直接引用的 CSS（生成后）
mini-program/       # 小程序资源（app-tokens-*.wxss 生成后）
tools/token-gen/    # 令牌生成器、SD 转换器、脚本与模板
  ├─ src/           # generate.mjs / sd-convert.mjs / themes.mjs
  ├─ tokens/        # tokens.json、dark.json、light.json（可新增主题）
  ├─ templates/     # Web/WXSS 基础模板
  └─ scripts/       # postinstall、sync、wx-switch
```

## 快速开始（本地）
```bash
# 1) 安装依赖（会触发 postinstall 自动生成 + 同步）
npm i

# 2) 生成主题合集（可选）
npm run gen:themes

# 3) 本地打开示例页（任一静态服务器均可）
npx serve web
# 或
python -m http.server -d web 5173
```

### Web 端引入与切换主题
```html
<link rel="stylesheet" href="/web/css/spark-themes.css" />
<!-- 切换：设置 data-theme 即可 -->
<html data-theme="dark">...</html>
<script>
  // 运行时切换
  document.documentElement.setAttribute('data-theme', 'light');
</script>
```

### 小程序端引入与切换主题
```bash
# 批量生成多主题
npm run gen:themes

# 切换到 dark（修改 app.wxss @import 指向 app-tokens-dark.wxss）
npm run wx:switch -- dark

# 切换到 light
npm run wx:switch -- light
```
将项目导入「微信开发者工具」，即可预览效果。

### 从 Style Dictionary 导入
```bash
# 将你的 style-dictionary.json 放到任意路径
node tools/token-gen/src/sd-convert.mjs \
  --in path/to/style-dictionary.json \
  --out tools/token-gen/tokens/tokens.json \
  --merge

# 生成与同步
npm run gen:tokens
```

## GitHub 仓库初始化（两种方式）

### 方式 A：一键脚本（推荐）
```bash
chmod +x ./setup_git.sh
./setup_git.sh git@github.com:YOUR_ORG/spark-ui-multiend.git
```

### 方式 B：手动执行
```bash
git init
git add .
git commit -m "feat: initial import of Spark UI MultiEnd with token-gen and themes"
git branch -M main
git remote add origin git@github.com:YOUR_ORG/spark-ui-multiend.git
git push -u origin main
```

## 常用命令
```jsonc
{
  "scripts": {
    "postinstall": "node tools/token-gen/scripts/postinstall.mjs",
    "gen:tokens": "node tools/token-gen/src/generate.mjs --in tools/token-gen/tokens/tokens.json --out tools/token-gen/dist --prefix sp --base-width 375 && node tools/token-gen/scripts/sync.mjs",
    "gen:sd": "node tools/token-gen/src/sd-convert.mjs --in tools/token-gen/sd-examples/style-dictionary.json --out tools/token-gen/tokens/tokens.json --merge && npm run gen:tokens",
    "gen:themes": "node tools/token-gen/scripts/themes.mjs",
    "wx:switch": "node tools/token-gen/scripts/wx-switch.mjs"
  }
}
```

## 约定与注意事项
- **Web** 使用 `:root[data-theme="..."]` 作用域变量，支持运行时切换。
- **小程序** 不支持 CSS Variables，采用「每主题一份 WXSS」策略；若需运行时切换，可改造成「主题前缀类」方案（我可以提供迁移脚本）。
- 设计令牌字段：`color.*`、`radius.*`、`size.*`、`effect.*`（其他字段会进入 `extra`，不影响生成）。
- `--base-width` 默认为 **375**，用于 px→rpx 的换算：`rpx = px / 375 * 750`。

---

如需**接入 CI（GitHub Actions）自动生成主题并发布构建产物**，我可以在此仓库基础上补一个工作流到 `.github/workflows/build.yml`，并上传 `web/css/*` 与 `mini-program/app-tokens-*.wxss` 为 Artifact 或发布到 GitHub Pages。


## CI（GitHub Actions）
仓库已内置工作流：`.github/workflows/build.yml`，在 **push 到 main**、**PR**、或 **手动触发** 时执行：

- `npm ci` → 安装依赖（包含 postinstall 自动生成）
- `npm run gen:themes` → 批量生成多主题
- 上传构建产物为 **Artifacts**（`spark-theme-assets`）：`web/css/**` 与 `mini-program/app-tokens-*.wxss`
- 将 `web/` 目录作为 **Pages 静态站点**发布（会自动把 `web/examples/video-chat.html` 复制为 `web/index.html`）

### 启用 GitHub Pages
1. 打开仓库 **Settings → Pages**，将 **Source** 设为 *GitHub Actions*（若未自动启用）。  
2. 推送到 `main` 后，Actions 将自动部署，页面 URL 会显示在 job 的 **Deploy to GitHub Pages** 步骤输出中。

> 如果你需要仅在发布 tag 时部署，可以把 `on.push.branches` 改为 `tags: ["v*"]` 并保留 `workflow_dispatch` 以便手动触发。
