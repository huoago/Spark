# 将 Spark 前端放入现有仓库的 `ui/` 子目录

包含：
- `ui/`：完整前端（多端样式、token 生成、themes、monorepo、CLI、示例、Actions）
- `.github/workflows/ui-build.yml`：构建 + Pages 部署（指向 `ui/web`）
- `.github/workflows/ui-publish.yml`：发布 `ui/packages/token-gen` 到 npm
- `scripts/push_ui_to_repo.sh` / `scripts/push_ui_to_repo.ps1`：一键合入 + 推送脚本

## 用法（macOS/Linux）
```bash
chmod +x scripts/push_ui_to_repo.sh
./scripts/push_ui_to_repo.sh /path/to/your/Spark git@github.com:huoago/Spark.git
```

## 用法（Windows PowerShell）
```powershell
.\scripts\push_ui_to_repo.ps1 "C:\path	o\Spark" "git@github.com:huoago/Spark.git"
```

> 合入后，首次在仓库 Settings → Pages 选择 GitHub Actions 作为 Source。
> 若要发布 CLI，请在 Secrets 添加 `NPM_TOKEN`，并按照 README 的「发布 CLI」章节打 tag（`token-gen-v*`）。
