#!/usr/bin/env bash
set -euo pipefail
REPO_DIR="${1:-}"
REMOTE_URL="${2:-}"
if [[ -z "$REPO_DIR" || -z "$REMOTE_URL" ]]; then
  echo "Usage: $0 /path/to/repo git@github.com:huoago/Spark.git"
  exit 1
fi
if [[ ! -d "$REPO_DIR/.git" ]]; then
  echo "Error: $REPO_DIR is not a git repository."
  exit 1
fi
rsync -a --delete "./ui/" "$REPO_DIR/ui/"
if [[ -d "$REPO_DIR/.github/workflows" ]]; then
  ts=$(date +%Y%m%d-%H%M%S); mkdir -p "$REPO_DIR/.github/workflows.bak-$ts"
  cp -r "$REPO_DIR/.github/workflows/." "$REPO_DIR/.github/workflows.bak-$ts/"
fi
mkdir -p "$REPO_DIR/.github/workflows"
rsync -a "./.github/workflows/" "$REPO_DIR/.github/workflows/"
pushd "$REPO_DIR" >/dev/null
git add ui .github/workflows
git commit -m "feat(ui): import Spark UI subdir + CI workflows (subdir mode)" || true
if ! git rev-parse --verify main >/dev/null 2>&1; then git branch -M main; fi
if ! git remote get-url origin >/dev/null 2>&1; then git remote add origin "$REMOTE_URL"; fi
git push -u origin main
popd >/dev/null
echo "Done. Check GitHub Actions → 'UI (subdir)' runs."
