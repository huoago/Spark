param(
  [Parameter(Mandatory=$true)][string]$RepoDir,
  [Parameter(Mandatory=$true)][string]$RemoteUrl
)
if (-not (Test-Path "$RepoDir\.git")) { Write-Error "Error: $RepoDir is not a git repository."; exit 1 }
robocopy ".\ui" "$RepoDir\ui" /MIR /NFL /NDL /NJH /NJS /NP | Out-Null
$wf = Join-Path $RepoDir ".github\workflows"
if (Test-Path $wf) {
  $ts = Get-Date -Format "yyyyMMdd-HHmmss"
  $bak = Join-Path $RepoDir ".github\workflows.bak-$ts"
  New-Item -ItemType Directory -Force -Path $bak | Out-Null
  robocopy $wf $bak /MIR | Out-Null
}
New-Item -ItemType Directory -Force -Path $wf | Out-Null
robocopy ".\.github\workflows" $wf /MIR | Out-Null
Push-Location $RepoDir
git add ui .github/workflows | Out-Null
git commit -m "feat(ui): import Spark UI subdir + CI workflows (subdir mode)" | Out-Null
try { git rev-parse --verify main | Out-Null } catch { git branch -M main | Out-Null }
try { git remote get-url origin | Out-Null } catch { git remote add origin $RemoteUrl | Out-Null }
git push -u origin main
Pop-Location
Write-Host "Done. Check GitHub Actions → 'UI (subdir)' runs."
