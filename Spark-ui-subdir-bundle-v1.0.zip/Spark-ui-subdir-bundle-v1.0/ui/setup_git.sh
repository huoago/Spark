#!/usr/bin/env bash
set -euo pipefail

REPO_URL="${1:-git@github.com:YOUR_ORG/spark-ui-multiend.git}"

git init
git add .
git commit -m "feat: initial import of Spark UI MultiEnd with token-gen and themes"
git branch -M main
git remote add origin "$REPO_URL"
git push -u origin main

echo "Pushed to $REPO_URL"
