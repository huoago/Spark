# spark-token-gen (CLI)

将 Design Tokens（JSON / Style Dictionary 导出）生成 Web CSS Variables 与 WXSS 实用类。

## 安装
```bash
npm i -g spark-token-gen   # 或在项目内作为 devDependency 安装
```

## 命令
```bash
spark-tokens --in tokens/tokens.json --out dist --prefix sp --base-width 375
```

- `--in`：输入 tokens 文件（支持扁平 JSON 或含 `{"value":…}` 的 SD 格式）
- `--out`：输出目录（默认 `dist/`）
- `--prefix`：CSS 变量前缀（默认 `sp`）
- `--base-width`：px→rpx 的基准宽度，默认 **375**（`rpx = px/375*750`）
